// let admin = require("firebase-admin");
// let bp = require("body-parser");
// var serviceAccount = require("json_server/mykey.json");

// let firebaseConfig = admin.initializeApp({
//     credential: admin.credential.cert(serviceAccount)
// });

// const app = initializeApp(firebaseConfig);
// const db = getFirestore(app);

// async function getPetCare(db) {
//     const citiesCol = collection(db, 'cities');
//     const citySnapshot = await getDocs(citiesCol);
//     const cityList = citySnapshot.docs.map(doc => doc.data());
//     return cityList;
// }


/* Limo 움직일떄 사용하는*/
let $movebtn = document.getElementById('movebtn');

let $text_ = document.getElementById('text_');

$movebtn.addEventListener("click", function move_robo() {
    console.log("star");
    $text_.textContent = "시작"
});

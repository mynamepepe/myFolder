## 강아지 똥 인식 ##
"""
from ultralytics import YOLO
import cv2
import numpy as np

# 사용자 정의 YOLO 모델 로드
dog_model = YOLO(r"C:\ws\py_proj_02\assets\yolo_data\findDog5.pt")
pooping_dog_model = YOLO(r"C:\ws\py_proj_02\assets\yolo_data\poopingDog2.pt")

# 'pooping-dog' 클래스의 인덱스 가져오기
pooping_dog_index = list(pooping_dog_model.names.values()).index("pooping-dog")

# 비디오 캡처 객체 생성 (0은 웹캠, 파일 경로를 지정하면 비디오 파일 사용)
cap = cv2.VideoCapture(0)

# 추적 기록을 저장할 딕셔너리
track_history = {}

while True:
    # 프레임 읽기
    ret, frame = cap.read()
    if not ret:
        break

    # 개 탐지 및 추적
    dog_results = dog_model.track(frame, persist=True)

    # 배변 중인 개 탐지
    pooping_dog_results = pooping_dog_model.predict(
        frame, classes=[pooping_dog_index], conf=0.3
    )

    # 개 추적 결과 처리
    if dog_results[0].boxes.id is not None:
        boxes = dog_results[0].boxes.xyxy.cpu().numpy().astype(int)
        track_ids = dog_results[0].boxes.id.cpu().numpy().astype(int)
        classes = dog_results[0].boxes.cls.cpu().numpy()

        for box, track_id, cls in zip(boxes, track_ids, classes):
            if dog_results[0].names[int(cls)] == "dog":
                x1, y1, x2, y2 = box
                track = track_history.get(track_id, [])
                track.append((int((x1 + x2) / 2), int((y1 + y2) / 2)))
                track_history[track_id] = track[-30:]  # 최근 30개의 위치만 유지

                # 바운딩 박스 그리기
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)

                # 추적 ID 표시
                cv2.putText(
                    frame,
                    f"Dog ID: {track_id}",
                    (x1, y1 - 10),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    (0, 255, 0),
                    2,
                )

                # 추적 경로 그리기
                if len(track) > 1:
                    cv2.polylines(frame, [np.array(track)], False, (0, 255, 255), 2)

    # 배변 중인 개 탐지 결과 처리
    for r in pooping_dog_results:
        boxes = r.boxes
        for box in boxes:
            if int(box.cls) == pooping_dog_index:
                x1, y1, x2, y2 = box.xyxy[0].cpu().numpy().astype(int)

                # 바운딩 박스 그리기 (빨간색으로)
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 2)

                # 'Pooping Dog' 라벨 표시
                cv2.putText(
                    frame,
                    f"Pooping Dog {box.conf[0]:.2f}",
                    (x1, y1 - 10),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    (0, 0, 255),
                    2,
                )

    # 결과 표시
    cv2.imshow("Dog Tracking and Pooping Detection", frame)

    # 'q' 키를 누르면 종료
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

# 리소스 해제
cap.release()
cv2.destroyAllWindows()
"""

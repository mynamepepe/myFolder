import asyncio
import websockets

"""
web소켓에서 데이터 넘겨줄때
A : 대변
B : 소변
C : 강아지 중앙 좌표

데이터 넘겨주는 형식 : A_x(좌표)_y(좌표)_s  예) A_35_45.5_s
"""


class WebsocketConnection:
    def __init__(self):
        self.ws = websockets.WebSocket()

    #  self.ws.connect("ws://172.30.1.15:81")  # IP는 수정해야함

    async def ws_conn_uri(self, uri, message):  # 연결할 IP
        uri = f"ws://{uri}"
        self.ws.connect(uri)
        print(f"{uri}Connected to Websocket server.")
        # print(f"{message} : socsend")
        await self.ws.send(message)

    async def msg_get(self):  # 아두이노에서 데이터 받기
        # time.sleep(2)
        try:
            self.result = await self.ws.recv()
            print("msg from 서버: " + self.result)
        except:
            self.result = "데이터 못받음"
        return self.result

    def close_soc(self):  # 연결 끊기
        self.ws.close()

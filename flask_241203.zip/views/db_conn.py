import firebase_admin
from firebase_admin import credentials, firestore
from pet_data_set import PetData


class DBstorage:
    def __init__(self):  # 파일 생성
        self.cred = credentials.Certificate(r"json_server\mykey.json")
        firebase_admin.initialize_app(self.cred)
        self.db = firestore.client()
        self.collection_main = "dogs"
        self.collection_sec = "dogs_poin"
        self.count = 1
        self.doc_ref1 = self.db.collection(self.collection_main)  # 메인 테이블
        self.doc_ref2 = self.db.collection(
            self.collection_sec
        )  # 보조 테이블 : 현재 산책 대상의 중심좌표 값
        self.name_ = ""
        self._id = ""  # 보조 컬렉션에 id 값
        self.user_id  # 산책 펫의 정보를 불러온다.

    def user_id(self):  # userid 확인
        for i in self.doc_ref2.stream():  # DB안에 2번째 테이블
            _id = i.id
            temp = i.to_dict()
            self.name_ = temp["name"]
        self.cur_data = {}
        for key in self.doc_ref1.stream():  # DB안에 1번째 테이블
            print(f"key.id : {key.id}")
            if (
                self.name_ == key.to_dict()["name"]
            ):  # 첫번째 컬렉션하고 두번째 컬렉션에 name 필드 비교(필드가 같으면 테이블 정보 가져온다.)
                self.cur_data = key.to_dict()  # 강아지 정보 가져오기
                self._id = key.id  # 고유 아이디 값

        if self._id != "":
            self.petobj_data_set()

    def petobj_data_set(self):
        #  flag = self.cur_data["flag"]
        flag = True
        timestamp = self.cur_data["timestamp"]
        neighborhood = self.cur_data["neighborhood"]
        name = self.cur_data["name"]
        petdata = PetData()
        petdata.init_set(  # db에서 받은 정보
            flag=flag, timestamp=timestamp, neighborhood=neighborhood, name=name
        )

    # # 데이터를 컬렉션에 추가합니다.
    # def insert_data(self):  # 물체 중심값 DB에 저장
    #     self._id.add({"center_x": "0.0", "center_y": "0.0"})

    # 데이터 수정
    def update_data(self, x, y):
        #    print(f"document id : {id}")
        x = str(x)
        y = str(y)
        data = {"center_x": x, "center_y": y}

    # self.doc_ref.document(id)

    #   print(f"값 변경 : {x}, {y}")

    def name_set(self, name):  # 현재 강아지 이름
        self.name_ = name

    # 데이터 삭제
    def delete_data(self):
        pass

    # 데이터 확인
    def print_data(self):
        print("test: ")
        test_da = self.db.collection(self.collection_main)
        for i in test_da.stream():
            print(f"현재 id값 | {i.id}")
            print(i.to_dict())

        print("DB완료")


"""
temp : 
{'pee_x': '', 'poo_x': '', 'center_y': '', 'poo_y': '', 'center_x': '', 'pee_y': '', 'name': 'db'}


center_x

center_y

name

pee_x

pee_y

poo_x

poo_y

"""

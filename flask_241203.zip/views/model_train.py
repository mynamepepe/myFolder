from ultralytics import YOLO
import cv2
import numpy as np
from pet_data_set import PetData

# from views.db_conn import DBstorage
print()


class MdlTrnnObjcRcgn:
    def __init__(self, model_cam=0):
        self.model = YOLO(r"C:\ws\py_proj_02\assets\yolo_data\findDog5.pt")
        self.colors = [
            (255, 0, 0),
            (0, 255, 0),
            (0, 0, 255),
            (255, 255, 0),
            (255, 0, 255),
            (0, 255, 255),
        ]
        # self.setdata = DBstorage()
        self.petdata = PetData()
        self.cap = cv2.VideoCapture(
            model_cam
        )  # 비디오 캡처 객체 생성 (0은 웹캠, 파일 경로를 지정하면 비디오 파일 사용)
        # 추적 기록을 저장할 딕셔너리
        self.track_history = {}

    def crd_mvm_get(self):
        pass

    # 강아지 중심좌표
    def handling_poin(self):
        self.center_x = int((self.x1 + self.x2) / 2)
        self.center_y = int((self.y1 + self.y2) / 2)
        # 콘솔에 강아지의 중심 좌표 출력
        # print(f"Dog ID: {self.track_id}, X: {self.center_x}, Y: {self.center_y}")
        self.track = self.track_history.get(self.track_id, [])
        self.track.append((self.center_x, self.center_y))
        self.track_history[self.track_id] = self.track[-30:]  # 최근 30개의 위치만 유지
        self.petdata.set_center_(self.center_x, self.center_y)

    # print(f"pet_center: {self.petdata.get_center_poin()}")

    # 모델 보여주기
    def showModelPrediction(self):
        while True:
            # 프레임 읽기 0+------
            ret, self.frame = self.cap.read()
            if not ret:
                break

            # YOLO 모델로 예측
            results = self.model.track(
                self.frame, persist=True, conf=0.25
            )  # 신뢰도 임계값을 0.25로 설정

            # 결과 처리
            if results[0].boxes.id is not None:
                boxes = results[0].boxes.xyxy.cpu().numpy().astype(int)
                track_ids = results[0].boxes.id.cpu().numpy().astype(int)
                classes = results[0].boxes.cls.cpu().numpy()
                for box, self.track_id, cls in zip(boxes, track_ids, classes):
                    # 클래스가 'dog'인 경우에만 처리
                    if results[0].names[int(cls)] == "dog":
                        self.x1, self.y1, self.x2, self.y2 = box
                        self.handling_poin()

                        # 바운딩 박스 그리기
                        cv2.rectangle(
                            self.frame,
                            (self.x1, self.y1),
                            (self.x2, self.y2),
                            (0, 255, 0),
                            2,
                        )

                        # 추적 ID 표시
                        cv2.putText(
                            self.frame,
                            f"Dog ID: {self.track_id}",
                            (self.x1, self.y1 - 10),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.5,
                            (0, 255, 0),
                            2,
                        )

                        # 추적 경로 그리기
                        if len(self.track) > 1:
                            cv2.polylines(
                                self.frame,
                                [np.array(self.track)],
                                False,
                                (0, 255, 255),
                                2,
                            )

                        ####################################################################33
                        # 결과 시각화

                # 결과 표시
                cv2.imshow("Dog Tracking", self.frame)

                # 'q' 키를 누르면 종료
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

    def camera_exit(self):
        # 리소스 해제
        self.cap.release()
        cv2.destroyAllWindows()

    ################################################################################################

    # 결과 처리
    # if results[0].boxes.id is not None:
    #     boxes = results[0].boxes.xyxy.cpu().numpy().astype(int)
    #     track_ids = results[0].boxes.id.cpu().numpy().astype(int)
    #     classes = results[0].boxes.cls.cpu().numpy()

    #     for box, track_id, cls in zip(boxes, track_ids, classes):
    #         # 클래스가 'dog'인 경우에만 처리
    #         if results[0].names[int(cls)] == "dog":
    #             x1, y1, x2, y2 = box
    #             center_x = int((x1 + x2) / 2)
    #             center_y = int((y1 + y2) / 2)

    #             # 콘솔에 강아지의 중심 좌표 출력
    #             print(f"Dog ID: {track_id}, X: {center_x}, Y: {center_y}")

    #             track = track_history.get(track_id, [])
    #             track.append((center_x, center_y))
    #             track_history[track_id] = track[-30:]  # 최근 30개의 위치만 유지

    #             # 바운딩 박스 그리기
    #             cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)

    #             # 추적 ID 표시
    #             cv2.putText(
    #                 frame,
    #                 f"Dog ID: {track_id}",
    #                 (x1, y1 - 10),
    #                 cv2.FONT_HERSHEY_SIMPLEX,
    #                 0.5,
    #                 (0, 255, 0),
    #                 2,
    #             )

    #             # 추적 경로 그리기
    #             if len(track) > 1:
    #                 cv2.polylines(frame, [np.array(track)], False, (0, 255, 255), 2)


# for result in results:
#                 boxes = result.boxes.cpu().numpy()
#                 if result.keypoints is not None:
#                     keypoints = result.keypoints

#                     print("Keypoints shape:", keypoints.shape)
#                     print("Keypoints data:")

#                     # 바운딩 박스 그리기
#                     for box in boxes:
#                         self.x1, self.y1, self.x2, self.y2 = map(int, box.xyxy[0])

#                         self.handling_poin()
#                         cv2.rectangle(
#                             self.frame,
#                             (self.x1, self.y1),
#                             (self.x2, self.y2),
#                             (0, 255, 0),
#                             2,
#                         )

#                     # 키포인트 그리기
#                     if hasattr(keypoints, "xy") and hasattr(keypoints.xy, "cpu"):
#                         kpts = keypoints.xy.cpu().numpy()
#                         for i, det_kpts in enumerate(kpts):
#                             print(f"  Detection {i}:")
#                             for j, kpt in enumerate(det_kpts):
#                                 x, y = map(int, kpt)
#                                 print(f"    Keypoint {j}: ({x}, {y})")
#                                 if x > 0 and y > 0:  # 0,0 좌표는 무시
#                                     cv2.circle(
#                                         self.frame,
#                                         (x, y),
#                                         5,
#                                         self.colors[j % len(self.colors)],
#                                         -1,
#                                     )
#                                     cv2.putText(
#                                         self.frame,
#                                         f"{j}",
#                                         (x + 5, y + 5),
#                                         cv2.FONT_HERSHEY_SIMPLEX,
#                                         0.5,
#                                         (255, 255, 255),
#                                         1,
#                                     )

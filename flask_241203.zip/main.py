from flask import Flask, render_template, jsonify, request
import json
from pet_data_set import PetData
from views.db_conn import DBstorage

from views.websoc_server import WebsocketConnection


app = Flask(__name__)


db = DBstorage()  # 디비 가져오기
petdata = PetData()
petdata.flag = True
# mdltrnnobjecrcgn = m_t.MdlTrnnObjcRcgn(0)  # 클래스 객체 생성  # 캠 설정
# if petdata.get_flag() == True:  # 움직임 시작 작업
#     webSocConn = WebsocketConnection()  # 웹소켓 시작
#     uri_ = "172.30.1.87:4000"
#     webSocConn.ws_conn_uri(uri=uri_, message="_start_limo_")  # localhost 를 넘겨줌

# mdltrnnobjecrcgn.showModelPrediction()  # 모델 보여줌

# mdltrnnobjecrcgn.camera_exit()  # 카메라 종료


@app.route("/")
def index():
    return render_template("index.html")


# @app.route('/video')

if __name__ == "__main__":
    app.run("0.0.0.0", port=5000, debug=True)

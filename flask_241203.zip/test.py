import firebase_admin
from firebase_admin import credentials, firestore
from pet_data_set import PetData  # 펫 객체

cred = credentials.Certificate(r"json_server\mykey.json")
firebase_admin.initialize_app(cred)
db = firestore.client()
collection_name1 = "dogs"
collection_name2 = "dogs_poin"
# document_id = "XN5Qd5bacL6oRrzaFFpB"
count = 1
doc_ref1 = db.collection(collection_name1)  # 메인 테이블
doc_ref2 = db.collection(collection_name2)  # 보조 테이블 : 현재 산책 대상의 중심좌표 값
name_ = ""


print("======================================")
cur_id = ""
for i in doc_ref2.stream():  # DB안에 2번째 테이블
    cur_id = i.id
    temp = i.to_dict()
    name_ = temp["name"]
    # print(cur_id)
    # print(cur_data)
    # print(type(cur_data))
    print("temp : ")
    print(temp)
    print(f"name_ : {name_}")

cur_data = {}
tem_arr = []  # 딕셔너리에서 value값만 저장
for key in doc_ref1.stream():  # DB안에 1번째 테이블
    if (
        name_ == key.to_dict()["name"]
    ):  # 첫번째 컬렉션하고 두번째 컬렉션에 name 필드 비교(필드가 같으면 테이블 정보 가져온다.)
        cur_data = key.to_dict()  # 강아지 정보 가져오기
        _id = key.id

print(f"_id : {_id}")

# for i in cur_data.items():


flag = True
timestamp = cur_data["timestamp"]
neighborhood = cur_data["neighborhood"]
name = cur_data["name"]

petdata = PetData(flag=flag, timestamp=timestamp, neighborhood=neighborhood, name=name)


print(f"{petdata.print_data()}")
print(f"{petdata.get_flag()}")

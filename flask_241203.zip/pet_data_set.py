## 산책하는 강아지 정보 ##
class PetData:
    def __init__(self):
        self.init_set

    def init_set(
        self,
        flag,
        timestamp,
        neighborhood,
        name,
        cen_x="0.0",
        cen_y="0.0",
        poo_x="0.0",
        poo_y="0.0",
        pee_x="0.0",
        pee_y="0.0",
        occur="C",
    ):
        self.flag = flag
        self.name = name
        self.neighborhood = neighborhood
        self.timestamp = timestamp
        self.center_x = cen_x
        self.center_y = cen_y
        self.poo_x = poo_x
        self.poo_y = poo_y
        self.pee_x = pee_x
        self.pee_y = pee_y
        self.occur = occur

    def set_flag(self, _flag):
        self.flag = _flag

    def set_center_(self, x, y):
        self.center_x = x
        self.center_y = y
        self.occur = "C"

    def set_poo_(self, x, y):
        self.poo_x = x
        self.poo_y = y
        self.occur = "A"

    def set_pee_(self, x, y):
        self.pee_x = x
        self.pee_y = y
        self.occur = "B"

    def get_poo_x(self):
        return self.poo_x

    def get_poo_y(self):
        return self.poo_y

    def get_pee_x(self):
        return self.pee_x

    def get_pee_y(self):
        return self.pee_y

    def get_flag(self):
        return self.flag

    # websocket 통신할떄 넘겨줄 값
    def get_poo_poin(self):
        return f"{self.occur}_{self.poo_x}_{self.poo_y}_s"

    def get_pee_poin(self):
        return f"{self.occur}_{self.pee_x}_{self.pee_y}_s"

    def get_center_poin(self):
        return f"{self.occur}_{self.center_x}_{self.center_y}_s"

    def print_data(self):
        return f"{self.flag} | {self.name} | {self.neighborhood} | {self.timestamp}"
